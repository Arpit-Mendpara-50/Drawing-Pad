//
//  Line.swift
//  DrawMe
//
//  Created by Arpit on 10/01/19.
//  Copyright © 2019 Arpit. All rights reserved.
//

import UIKit

struct Line {
    let strokeWidth: Float
    let color: UIColor
    var points: [CGPoint]
}
